package main;

import java.util.ArrayList;
import java.util.logging.Logger;
import hexaware.dao.ServiceProviderImpl;
import hexaware.dto.Bank;
import hexaware.dto.BankAccount;
import exceptions.AccountNumberInvalidException;
import exceptions.InsufficientFundsException;
import exceptions.NegativeAmountException;

public class MainMod {

	 // Create a logger for the MainMod class
    private static final Logger logger = Logger.getLogger(MainMod.class.getName());

    public static void main(String[] args) {
        // TODO Auto-generated method stub
    	logger.info("Starting the MainMod program.");
        BankAccount obj1 = new BankAccount("Haritha", "Current", 80000.50);
        BankAccount obj2 = new BankAccount("Bhavya", "Savings", 20000.50);
        BankAccount obj3 = new BankAccount("Sanjana", "Current", 35000.50);

        ArrayList<BankAccount> myList = new ArrayList<>();
        myList.add(obj1);
        myList.add(obj2);
        myList.add(obj3);

        

        Bank myBank = new Bank("ICICI", myList);
        System.out.println(myBank);

        try {
            // Operations with potential exceptions
            ServiceProviderImpl myServiceObj = new ServiceProviderImpl(myBank);

            // Check Balance
            try {
                logger.info("Checking balance of account 1000...");
                System.out.println("Balance of account 1000 : " + myServiceObj.checkBalance(1000));
            } catch (AccountNumberInvalidException e) {
                logger.warning("Error - Account Number Invalid: " + e.getMessage());
            }

            // Deposit
            try {
                logger.info("Depositing to account 1001...");
                System.out.println("Status of deposit: " + myServiceObj.deposit(1001, 5000.50));
            } catch (AccountNumberInvalidException e) {
                logger.warning("Error - Account Number Invalid: " + e.getMessage());
            } catch (NegativeAmountException e) {
                logger.warning("Error - Negative Amount: " + e.getMessage());
            }

            // Check Balance Again
            try {
                logger.info("Checking balance of account 1001...");
                System.out.println("Balance of account  : 1001  :" + myServiceObj.checkBalance(1001));
            } catch (AccountNumberInvalidException e) {
                logger.warning("Error - Account Number Invalid: " + e.getMessage());
            }

            // Withdraw
            try {
                logger.info("Withdrawing from account 1002...");
                System.out.println("Status of withdrawal: " + myServiceObj.withdraw(1002, 5000.50));
            } catch (AccountNumberInvalidException e) {
                logger.warning("Error - Account Number Invalid: " + e.getMessage());
            } catch (NegativeAmountException e) {
                logger.warning("Error - Negative Amount: " + e.getMessage());
            } catch (InsufficientFundsException e) {
                logger.warning("Error - Insufficient Funds: " + e.getMessage());
            }

            // Check Balance After Withdrawal
            try {
                logger.info("Checking balance of account 1002...");
                System.out.println("Balance of account 1002: " + myServiceObj.checkBalance(1002));
            } catch (AccountNumberInvalidException e) {
                logger.warning("Error - Account Number Invalid: " + e.getMessage());
            }

            // Create Account
            logger.info("Creating a new account...");
            System.out.println("New account status " + myServiceObj.createAccount(new BankAccount("Sasidhar", "Savings", 10000.0)));

            System.out.println(myBank);

            // Remove Account
            try {
                logger.info("Removing account 1001...");
                System.out.println("Remove account status " + myServiceObj.removeAccount(1001));
            } catch (AccountNumberInvalidException e) {
                logger.warning("Error - Account Number Invalid: " + e.getMessage());
            }

            System.out.println(myBank);

        } finally {
            // This block will be executed whether an exception occurs or not
            // Logging the final state of the bank
            logger.info("Final state of the bank: " + myBank);
            // Logging the end of the program
            logger.info("MainMod program completed.");
        }
    }
}
