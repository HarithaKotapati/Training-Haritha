package hexaware.dao;
import hexaware.dto.BankAccount;
import exceptions.AccountNumberInvalidException;
import exceptions.InsufficientFundsException;
import exceptions.NegativeAmountException;


public interface IServiceProvider {
	BankAccount searchAccount(long accountNumber) throws AccountNumberInvalidException;

    double checkBalance(long accountNumber) throws AccountNumberInvalidException;

    boolean deposit(long accountNumber, double amount) throws AccountNumberInvalidException, NegativeAmountException;

    boolean withdraw(long accountNumber, double amount) throws AccountNumberInvalidException, InsufficientFundsException, NegativeAmountException;

    boolean createAccount(BankAccount newAcc);

    boolean removeAccount(long accountNumber) throws AccountNumberInvalidException;
}
