package exceptions;

public class AccountNumberInvalidException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AccountNumberInvalidException(String message) {
        super(message);
    }
}
