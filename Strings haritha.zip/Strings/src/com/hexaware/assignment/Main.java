package com.hexaware.assignment;

public class Main {
    public static void main(String[] args) {
    	String exampleURL = "https://www.javatpoint.com/StringBuilder-class?param1=StringBuilder&param2=article";
        URLParser parser = new URLParser(exampleURL);

        System.out.println("Protocol: " + parser.getProtocol());
        System.out.println("Host: " + parser.getHost());
        System.out.println("Path: " + parser.getPath());
        System.out.println("Query Parameters: " + parser.getQueryParams());

        System.out.println();

        // Example of using URLBuilder
        URLBuilder builder = new URLBuilder();
        builder.setProtocol("https");
        builder.setHost("www.javatpoint.com");
        builder.setPath("Java/String");
        builder.addQueryParam("param1", "StringBuilder");
        builder.addQueryParam("param2", "article");

        String constructedURL = builder.build();
        System.out.println("Constructed URL: " + constructedURL);
    }
}