package com.hexaware.assignment;
import java.util.HashMap;
import java.util.Map;

public class URLBuilder {
    private String protocol;
    private String host;
    private String path;
    private Map<String, String> queryParams;

    public URLBuilder() {
        this.queryParams = new HashMap<>();
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public void addQueryParam(String key, String value) {
        queryParams.put(key, value);
    }

    public String build() {
        StringBuilder urlBuilder = new StringBuilder();
        urlBuilder.append(protocol).append("://").append(host).append(path);

        if (!queryParams.isEmpty()) {
            urlBuilder.append("?");
            for (Map.Entry<String, String> entry : queryParams.entrySet()) {
                urlBuilder.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
            }
            urlBuilder.deleteCharAt(urlBuilder.length() - 1); // Remove the trailing "&"
        }

        return urlBuilder.toString();
    }
}