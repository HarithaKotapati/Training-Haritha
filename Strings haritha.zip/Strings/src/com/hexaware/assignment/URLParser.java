package com.hexaware.assignment;
import java.util.HashMap;
import java.util.Map;

public class URLParser {
    private String protocol;
    private String host;
    private String path;
    private Map<String, String> queryParams;

    public URLParser(String url) {
        parseURL(url);
    }

    private void parseURL(String url) {
        String[] parts = url.split("://");
        if (parts.length >= 2) {
            protocol = parts[0];
            String remaining = parts[1];

            String[] hostPathParams = remaining.split("/", 2);
            host = hostPathParams[0];

            if (hostPathParams.length == 2) {
                String[] pathQueryParams = hostPathParams[1].split("\\?", 2);
                path = "/" + pathQueryParams[0];

                if (pathQueryParams.length == 2) {
                    queryParams = parseQueryParams(pathQueryParams[1]);
                }
            } else {
                path = "/";
            }
        }
    }

    private Map<String, String> parseQueryParams(String queryString) {
        Map<String, String> params = new HashMap<>();
        String[] pairs = queryString.split("&");
        for (String pair : pairs) {
            String[] keyValue = pair.split("=");
            if (keyValue.length == 2) {
                params.put(keyValue[0], keyValue[1]);
            }
        }
        return params;
    }

    public String getProtocol() {
        return protocol;
    }

    public String getHost() {
        return host;
    }

    public String getPath() {
        return path;
    }

    public Map<String, String> getQueryParams() {
        return queryParams;
    }
}