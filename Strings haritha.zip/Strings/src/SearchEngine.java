import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SearchEngine {
    private String originalText;

    public SearchEngine(String originalText) {
        this.originalText = originalText;
    }

    // Find all occurrences of a substring in the original text
    public List<Integer> findAllOccurrences(String substring) {
        List<Integer> occurrences = new ArrayList<>();
        Pattern pattern = Pattern.compile(substring);
        Matcher matcher = pattern.matcher(originalText);

        while (matcher.find()) {
            occurrences.add(matcher.start());
        }

        return occurrences;
    }

    // Highlight matched substrings in the original text
    public String highlightMatches(String substring) {
        String highlightedText = originalText;
        List<Integer> occurrences = findAllOccurrences(substring);

        // Add HTML-style highlighting to matched substrings
        for (int i = occurrences.size() - 1; i >= 0; i--) {
            int start = occurrences.get(i);
            int end = start + substring.length();
            highlightedText = highlightedText.substring(0, start) +
                    "<b>" + highlightedText.substring(start, end) + "</b>" +
                    highlightedText.substring(end);
        }

        return highlightedText;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Take input for the original text
        System.out.print("Enter the original text: ");
        String originalText = scanner.nextLine();
        SearchEngine searchEngine = new SearchEngine(originalText);

        // Take input for the substring to search for
        System.out.print("Enter the substring to search for: ");
        String searchString = scanner.nextLine();

        List<Integer> occurrences = searchEngine.findAllOccurrences(searchString);

        System.out.println("Occurrences of '" + searchString + "': " + occurrences);

        String highlightedText = searchEngine.highlightMatches(searchString);
        System.out.println("Highlighted Text:\n" + highlightedText);

        scanner.close();
    }
}
